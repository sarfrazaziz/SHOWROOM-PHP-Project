<?php
$con=mysqli_connect("localhost","root","","news-cms") or die("connection failed".mysqli_connect_error())

?>